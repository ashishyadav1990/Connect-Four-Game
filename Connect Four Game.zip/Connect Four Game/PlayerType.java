package edu.nyu.cs.pqs;

enum PlayerType {
  
  Human, Computer

}
