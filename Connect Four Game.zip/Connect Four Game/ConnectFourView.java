package edu.nyu.cs.pqs;

import java.awt.BorderLayout;

import javax.swing.text.html.StyleSheet;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import edu.nyu.cs.pqs.ConnectFourModel;

public class ConnectFourView implements ConnectFourListener {

  Player player;
  Color[][] gridView = new Color[6][7];

  private JFrame frame = new JFrame("Connect Four");
  private JFrame frameStart = new JFrame("Which Game?");
  private JButton startButton = new JButton("Start");
  private JButton resetButton = new JButton("Reset");
  private JButton quitButton = new JButton("Quit");
  private JTextArea textArea = new JTextArea();
  private JButton[] buttonFields = new JButton[42];
  private JButton playerPlayer = new JButton("Player vs. Player");
  private JButton playerComputer = new JButton("Player vs. Computer");
  private JPanel panel = new JPanel(new BorderLayout());
  private JPanel upperPanel = new JPanel(new GridLayout(0, 7));
  private JPanel bottomPanel = new JPanel(new BorderLayout());
  private ConnectFourModel model;

  public ConnectFourView(ConnectFourModel model) {

    this.model = model;


    JPanel panelStart = new JPanel(new BorderLayout());

    panelStart.add(playerPlayer, BorderLayout.WEST);
    panelStart.add(playerComputer, BorderLayout.EAST);

    //GridLayout grid = new GridLayout(0,7);
    //upperPanel.add(grid);//(grid, BorderLayout.CENTER);
    /*
     * JLabel[] labelFields = new JLabel[42];
     * 
     * 
     * for(int i=0;i<labelFields.length;i++){ labelFields[i] = new JLabel("1");
     * //labelFields[i].setForeground(Color.red);
     * 
     * }
     * 
     * for(int i=0;i<labelFields.length;i++){ panel.add(labelFields[i]);
     * labelFields[i].setBackground(Color.green); }
     */

    for (int i = 0; i < buttonFields.length; i++) {
      buttonFields[i] = new JButton("");
      //labelFields[i].setForeground(Color.red);

    }

    for (int i = 0; i < buttonFields.length; i++) {
      upperPanel.add(buttonFields[i]);
      buttonFields[i].setBackground(Color.white);
    }

    bottomPanel.add(startButton, BorderLayout.WEST);
    bottomPanel.add(quitButton, BorderLayout.EAST);
    bottomPanel.add(resetButton, BorderLayout.CENTER);
    panel.add(upperPanel, BorderLayout.NORTH);
    panel.add(bottomPanel, BorderLayout.SOUTH);
    panel.add(textArea, BorderLayout.CENTER);

    frameStart.getContentPane().add(panelStart);
    frameStart.setSize(300, 100);

    frameStart.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    playerPlayer.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        buttonPlayerPlayerPressed();
      }
    });

    playerComputer.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        buttonPlayerComputerPressed();
      }
    });

    for (int i = 0; i < buttonFields.length; i++) {
      //break;
      buttonFields[i].addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent arg0) {

          for (int i = 0; i < buttonFields.length; i++) {

            if (arg0.getSource() == buttonFields[i])
              buttonPressed(i);

          }

        }

      });
    }

    frameStart.setVisible(true);
  }

  private void buttonPlayerPlayerPressed() {

    Player player1 = new Player(PlayerType.Human,PlayerColor.Blue);
    Player player2 = new Player(PlayerType.Human,PlayerColor.Red);

    model.addListener(this,player1);
    model.addListener(this,player2);
    
    
    frame.getContentPane().add(panel);

    frame.setSize(200, 200);

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    frameStart.setVisible(false);
    model.startGame();

  }

  private void buttonPlayerComputerPressed() {
    
    Player player1 = new Player(PlayerType.Human,PlayerColor.Blue);
    Player player2 = new Player(PlayerType.Computer,PlayerColor.Red);

    model.addListener(this,player1);
    model.addListener(this,player2);

    frame.getContentPane().add(panel);

    frame.setSize(200, 200);

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
    frameStart.setVisible(false);
    model.startGame();

  }
  static int u=0;

  private void buttonPressed(int i) {
    int row = i / 7;
    int col = i % 7;
    int j = 0;
    
    System.out.println("Ashish " + u);
    u++;
    for (j = 0; j < 6; j++) {
      if (buttonFields[j * 7 + col].getBackground() == Color.white) {
        continue;
      } else {
        break;
      }
    }
    PositionZeroIndexed pos = new PositionZeroIndexed();
    pos.setX(j-1);
    pos.setY(col);
    System.out.println(pos.getX());
    System.out.println(pos.getY());
    //buttonFields[(j - 1) * 7 + col].setBackground(Color.red);
    //buttonFields[(j - 1) * 7 + col].setEnabled(false);
    model.playerMoved(player, pos);
  }
  
  private int max(int a,int b){
    if(a>b)
      return a;
    else
      return b;
  }
  
  private int min(int a,int b){
    if(a<b)
      return a;
    else
      return b;
  }
  
  private PositionZeroIndexed findWinPosition(Player player){
    
    int winRowIndex =0;
    int winColIndex =0;
    int count = 0;
    for(int i=0;i<41;i++){
      int row = i/7;
      int col = i%7;
      gridView[row][col] = buttonFields[i].getBackground();
    }
    
    for(int i=0;i<6;i++){
      for(int j=0;j<7;j++){
        count = 0;
        StyleSheet style = new StyleSheet();
        gridView[i][j] = style.stringToColor(player.getPlayerColor().toString());
        
        for(int k=max(j-3,0);k<min(j+3,7);k++){
          if(gridView[i][k]!=style.stringToColor(player.getPlayerColor().toString())){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              winRowIndex = i;
              winColIndex = k;
              PositionZeroIndexed finalPos = new PositionZeroIndexed();
              finalPos.setX(winRowIndex);
              finalPos.setX(winColIndex);
              return finalPos;
            
            
            }
          }
        }
        count = 0;
        for(int k=max(i-3,0);k<min(i+3,6);k++){
          if(gridView[k][j]!=style.stringToColor(player.getPlayerColor().toString())){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              winRowIndex = k;
              winColIndex = j;
              PositionZeroIndexed finalPos = new PositionZeroIndexed();
              finalPos.setX(winRowIndex);
              finalPos.setX(winColIndex);
              return finalPos;
            
            }
          }
        }
        count =0;
        int k;
        int l;
        for(k=max(i-3,0),l=max(j-3,0);k<min(i+3,6) && l<min(j+3,7);k++,l++){
          if(gridView[k][l]!=style.stringToColor(player.getPlayerColor().toString())){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              winRowIndex = k;
              winColIndex = l;
              PositionZeroIndexed finalPos = new PositionZeroIndexed();
              finalPos.setX(winRowIndex);
              finalPos.setX(winColIndex);
              return finalPos;
            }
            
          }
        }
        count =0 ;
        for(k=min(i+3,5),l=max(j-3,0);k>max(i-3,0) && l<min(j+3,7);k--,l++){
          if(gridView[k][l]!=style.stringToColor(player.getPlayerColor().toString())){
            System.out.println("Count is " + count);
            count=0;
          }
          else{
            count++;
            if(count==4){
              winRowIndex = k;
              winColIndex = l;
              PositionZeroIndexed finalPos = new PositionZeroIndexed();
              finalPos.setX(winRowIndex);
              finalPos.setX(winColIndex);
              return finalPos;
            }
            
          }
        }
        gridView[i][j] = Color.white;
      }
    }
    
    
    
    
    Random row = new Random();
    int rowIndex = row.nextInt(6);
    
    Random col = new Random();
    int colIndex = col.nextInt(7);
    PositionZeroIndexed finalPos = new PositionZeroIndexed();
    finalPos.setX(rowIndex);
    finalPos.setX(colIndex);
    return finalPos;
    
    
  }

  public void makeMoveView(Player player) {
    this.player = player;
    if (player.getPlayerType() == PlayerType.Human) {
      textArea.setText("Player " + player.getPlayerId() + " move!!\n");
    } else {
      PositionZeroIndexed pos =findWinPosition(player);
      int rowIndex = pos.getX();
      int colIndex = pos.getY();
      int linearPosition = rowIndex*7+colIndex;
      buttonPressed(linearPosition);
    }
  }

  public void playerMovedView(Player player, PositionZeroIndexed pos) {

    PlayerColor playerColor = player.getPlayerColor();
    int posX = pos.getX();
    int posY = pos.getY();
    int linearPos = (posX) * 7 + posY;
    StyleSheet style = new StyleSheet();
    Color pColor = style.stringToColor(playerColor.toString());
    buttonFields[linearPos].setBackground(pColor);
    buttonFields[linearPos].setEnabled(false);

  }

  public void gameWonView(Player player) {
    System.out.println("Got it");
    //textArea.setText("");
    
    textArea.setText("Player" + player.getPlayerId() + "has won the game\n");
    
    
    
  }

  public void gameTiedView() {
    textArea.setText("Game Tied\n");
  }

  public void gameStarted() {

    textArea.append("Game Started!!\n");

  }

  //  public void reset() {
  //
  //    textArea.append();
  //  }

}
