package edu.nyu.cs.pqs;



public class Player {
  private PlayerID playerId;
  private PlayerType playerType;
  private PlayerColor playerColor;
  
  Player(PlayerType type, PlayerColor color){
    
    playerId = new PlayerID();
    this.playerType = type;
    this.playerColor = color;
  }
 
  public int getPlayerId(){
    return playerId.getID();
  }
  
  public PlayerType getPlayerType(){
    return this.playerType;
  }
  
  public PlayerColor getPlayerColor(){
    return this.playerColor;
  }
  
  
  

}
