package edu.nyu.cs.pqs;

public interface ConnectFourListener {
  
  
  public void gameStarted();
  
  //public void chipDropped(PlayerID,Position);
  
  //public void reset();
  
  public void makeMoveView(Player player); // just display in the text field.
  
  public void gameWonView(Player player);
  public void gameTiedView();
  public void playerMovedView(Player player, PositionZeroIndexed position);
}
