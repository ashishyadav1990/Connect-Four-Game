package edu.nyu.cs.pqs;

import java.util.*;

class PlayerID {
  
  private int id=0;
  private static int lastUsedId=-1;
  
  
  //private static Set<Integer> ID = new HashSet<Integer>();
  
  
  PlayerID(){
    this.id=lastUsedId+1;
    lastUsedId = lastUsedId+1;
  }
  
  public int getID(){
    return this.id;
  }
}
