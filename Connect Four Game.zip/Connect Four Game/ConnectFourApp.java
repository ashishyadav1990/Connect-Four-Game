package edu.nyu.cs.pqs;

import edu.nyu.cs.pqs.ConnectFourApp;
import edu.nyu.cs.pqs.ConnectFourModel;
import edu.nyu.cs.pqs.ConnectFourView;

public class ConnectFourApp {

  private void startGame() {

    ConnectFourModel model = new ConnectFourModel();
    //Player player1 = new Player(PlayerType.Human)

    new ConnectFourView(model);
    //new ConnectFourView(model);

    //model.startGame();

  }

  

  public static void main(String[] args) {

    new ConnectFourApp().startGame();

  }
}
