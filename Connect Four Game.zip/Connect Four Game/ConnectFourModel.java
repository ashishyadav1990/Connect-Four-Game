package edu.nyu.cs.pqs;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.text.html.StyleSheet;

import edu.nyu.cs.pqs.ConnectFourListener;

public class ConnectFourModel {

  //Grid grid = new Grid().Builder(6,7);//.row(6).col(7);

  private static PlayerColor[][] grid = new PlayerColor[6][7];
  
  private boolean gameWon=false;
  private boolean gameTied=false;

  private static List<ConnectFourListener> listeners =

  new ArrayList<ConnectFourListener>();

  private static List<Player> players = new ArrayList<Player>();
  //private Map<Player, ConnectFourListener> mapListener = new HashMap<Player, ConnectFourListener>();

  public void makeMoveModel(Player player) {

    for (ConnectFourListener listener : listeners) {

      listener.makeMoveView(player);

    }

  }
  
  private int max(int a,int b){
    if(a>b)
      return a;
    else
      return b;
  }
  
  private int min(int a,int b){
    if(a<b)
      return a;
    else
      return b;
  }

  private boolean isGameWon(Player player, PositionZeroIndexed pos) {

    System.out.println("World !!!!!");
    
    
    int rowIndex = pos.getX();
    int colIndex = pos.getY();
    int count =0 ;
    System.out.println(grid);
    grid[rowIndex][colIndex] = player.getPlayerColor();
    for(int i=0;i<6;i++){
      for(int j=0;j<7;j++){
        count =0 ;
        StyleSheet style = new StyleSheet();
        
        for(int k=max(j-3,0);k<min(j+3,7);k++){
          if(grid[i][k]!=player.getPlayerColor()){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              return true;
            
            
            }
          }
        }
        count = 0;
        for(int k=max(i-3,0);k<min(i+3,6);k++){
          if(grid[k][j]!=player.getPlayerColor()){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              return true;
            
            }
          }
        }
        count =0;
        int k;
        int l;
        for(k=max(i-3,0),l=max(j-3,0);k<min(i+3,6) && l<min(j+3,7);k++,l++){
          if(grid[k][l]!=player.getPlayerColor()){
            count=0;
          }
          else{
            count++;
            System.out.println("Count is " + count);
            if(count==4){
              return true;
            }
            
          }
        }
        count =0 ;
        for(k=min(i+3,5),l=max(j-3,0);k>max(i-3,0) && l<min(j+3,7);k--,l++){
          if(grid[k][l]!=player.getPlayerColor()){
            System.out.println("Count is " + count);
            count=0;
          }
          else{
            count++;
            if(count==4){
              return true;
            }
            
          }
        }
      }
    }
    return false;

  }
  
  private boolean isGameTied(Player player, PositionZeroIndexed pos) {

    for(int i=0;i<6;i++){
      for(int j=0;j<7;j++){
        if(grid[i][j]==PlayerColor.White){
          gameTied = false;
          return false;
        }
      }
    }
    if(gameWon == false){
      gameTied = true;
      return true;
    }
    return false;

  }

  public void notifyGameWon(Player player) {

    System.out.println("Notifying");
    for (ConnectFourListener listener : listeners) {
      listener.gameWonView(player);
    }
  }
  
  
  public void notifyGameTied() {

    for (ConnectFourListener listener : listeners) {
      listener.gameTiedView();
    }
  }
  
  
  public void updateListener(Player player,PositionZeroIndexed position) {
    
    int row = position.getX();
    int col = position.getY();
    grid[row][col] = player.getPlayerColor();

    for (ConnectFourListener listener : listeners) {
      listener.playerMovedView(player,position);
      
    }
    
  }

  
  private Player findNextPlayer(Player player){
    if(player.getPlayerId() == players.size()-1){
      return players.get(0);
    }
    else{
      return players.get(player.getPlayerId()+1);
    }
  }
  
  public void playerMoved(Player player, PositionZeroIndexed position) {

    updateListener(player,position);
    if (isGameWon(player, position)) {
      gameWon = true;
      notifyGameWon(player);
    }
//    else if(isGameTied(player,position)){
//      notifyGameTied();
//    }
    else
      makeMoveModel(findNextPlayer(player));
  }

  public void addListener(ConnectFourListener listener,Player player) {

    listeners.add(listener);
    players.add(player);

  }
  public void startGame() {
    
    System.out.println(players.get(0).getPlayerColor());
    System.out.println(players.get(1).getPlayerColor());
    makeMoveModel(players.get(0));

    //resetNum();

    //fireGameStartEvent();

  }
  
  public void endGame(){
    
  }

}
