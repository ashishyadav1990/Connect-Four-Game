package edu.nyu.cs.pqs;

public enum PlayerColor {

  Red, Green, Yellow, Blue, White;
}
