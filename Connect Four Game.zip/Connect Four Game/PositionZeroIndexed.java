package edu.nyu.cs.pqs;

public class PositionZeroIndexed {

  int X;
  int Y;
  public int getX(){
    return X;
  }
  
  public int getY(){
    return Y;
  }
  
  public void setX(int x){
    this.X=x;
  }
  
  public void setY(int y){
    this.Y=y;
  }
}
