package edu.nyu.cs.pqs;

public class Grid {

  private final int row;
  private final int col;
  
  public static class Builder{
    
    private int row =6;
    private int col =7;
    
    public Builder(){
      
    }
    
    
    public Builder numRow(int val){
      row = val;
      return this;
    }
 
    
    public Builder numCol(int val){
      col = val;
      return this;
    }
    
    
    public Grid build(){
      return new Grid(this);
    }
    
  }
  
  
  private Grid(Builder builder){
    row = builder.row;
    col = builder.col;
  }
  
  
  public int getRow(){
    return this.row;
  }
  
  public int getCol(){
    return this.col;
  }
}
